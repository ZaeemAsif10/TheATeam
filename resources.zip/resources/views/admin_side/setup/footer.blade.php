<!--start footer-->
<footer class="footer">
    <div class="footer-text">
        Copyright © 2021. All right reserved.
    </div>
</footer>
<!--end footer-->
